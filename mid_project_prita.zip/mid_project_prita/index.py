# -------------------------------------------------------------------------------------------------------
# Author    : Prita
# Challenge : Midterm Project
# Date      : 2019/03/21
# Task      : Creating assessment tool for point source pollution in Great Barrier Reef Catchment
# -------------------------------------------------------------------------------------------------------

# Import arcpy module
import arcpy, shutil, os

# Activate the spatial analyst tool
arcpy.CheckOutExtension("spatial")
arcpy.env.overwriteOutput = True

# Local variables:
directory = "C:/Py/NRS568/Code/mid_project_prita/"
input_directory = directory + "data/input/"
temp_directory = directory + "data/temp/"
output_directory = directory + "data/output/"

basin = input_directory + "basin.shp"
soil = input_directory + "soil.shp"
gbr = temp_directory + "gbr.shp"
output = output_directory + "final.shp"

# Create temporary directory if doesn't exists
if not os.path.exists(temp_directory):
    os.mkdir(temp_directory)
    print "Temporary directory created [" + temp_directory + "]"

# Create output directory if doesn't exists
if not os.path.exists(output_directory):
    os.mkdir(output_directory)
    print "Output directory created [" + output_directory + "]"

# Process: Clip the Great Barrier Reef catchment from basin
arcpy.Clip_analysis(basin, soil, gbr, "")

# Set up environment workspace
arcpy.env.workspace = input_directory
listAll = arcpy.ListFeatureClasses()
listPoint = [x for x in listAll if "qsl_" in x]

# # Dissolve to remove the other unnecessary field per each input
for point in listPoint:
    point_input = input_directory + point
    point_output_1 = temp_directory + point
    arcpy.Dissolve_management(point_input, point_output_1, "FID", "", "SINGLE_PART", "DISSOLVE_LINES")
    print "Point source pollution shape file has been created [" + point.replace(".shp","").replace("qsl_","") + "]"

arcpy.env.workspace = temp_directory
listAllTemp = arcpy.ListFeatureClasses()
listPointTemp = [x for x in listAllTemp if "qsl_" in x]
listMerge = tuple(zip(listAllTemp, listPointTemp))
i = 0
for j in listMerge:
    index = "INDEX" + str(i+1)
    var0 = temp_directory + j[0]
    var1 = temp_directory + j[1]
    var2 = temp_directory + j[0].replace(".shp", "") + "_" + str(i) + ".shp"
    var3 = gbr.replace(".shp", "") + "_" + str(i-1) + ".shp"
    var4 = gbr.replace(".shp", "") + "_" + str(i) + ".shp"
    if i ==0:
        # Process: Spatial Join the clipped basin and each point source of polution
        arcpy.SpatialJoin_analysis(var0, var1, var2)

        # Process: Add new field
        arcpy.AddField_management(var2, index, "DOUBLE", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")

        # Process: Calculate Field using other field value
        arcpy.CalculateField_management(var2, index, "[Join_Count]", "VB", "")

        # Process : delete unnecessary field
        arcpy.DeleteField_management(var2, "Join_Count")
        arcpy.DeleteField_management(var2, "TARGET_FID")
        arcpy.DeleteField_management(var4, "Id")
        print "Point source polution index has been added [" + j[1].replace(".shp","").replace("qsl_","") + "]"
    else:
        # Process: Spatial Join the clipped basin and each point source of polution
        arcpy.SpatialJoin_analysis(var3, var1, var4)

        # Process: Add new field
        arcpy.AddField_management(var4, index, "DOUBLE", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")

        # Process: Calculate Field using other field value
        arcpy.CalculateField_management(var4, index, "[Join_Count]", "VB", "")

        # Process : delete unnecessary field
        arcpy.DeleteField_management(var4, "Join_Count")
        arcpy.DeleteField_management(var4, "TARGET_FID")
        arcpy.DeleteField_management(var4, "Id")
        print "Point source polution index has been added [" + j[1].replace(".shp", "").replace("qsl_", "") + "]"
    i = i + 1

listFinalTemp = arcpy.ListFeatureClasses()
listGbrTemp = [x for x in listFinalTemp if "gbr_" in x]
listGbrTemp.sort(reverse=True)
final_temp = temp_directory + listGbrTemp[0]

# Process: Add Field INDEX
arcpy.AddField_management(final_temp, "INDEX", "FLOAT", "", "", "", "", "NULLABLE", "NON_REQUIRED", "")

# Process: Calculate Field INDEX
arcpy.CalculateField_management(final_temp, "INDEX", "([INDEX1] + [INDEX2] + [INDEX3] + [INDEX4] + [INDEX5])/ [AREA]", "VB", "")
print "Point source polution index has been calculated [all point source of polution]"

# Process: Copy Features
arcpy.CopyFeatures_management(final_temp, output, "", "0", "0", "0")
print "Final output has been created [" + output + "]"

# Delete temporary directory
if os.path.exists(temp_directory):
    shutil.rmtree(temp_directory)
    print "Temporary directory has been deleted [" + temp_directory + "]"
